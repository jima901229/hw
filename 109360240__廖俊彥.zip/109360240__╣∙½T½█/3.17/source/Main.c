#include<stdio.h>
#include<stdlib.h>
int main(void)
{
	int a;
	float b;
	float c;
	float d;
	float e;
	float f;

	printf("enter account number (-1 to 100)\n");
	scanf_s("%d", &a);
	if (a == -1)
		return 0;
	printf("enter begining balance \n");
	scanf_s("%f", &b);
	printf("enter total charge\n");
	scanf_s("%f",& c);
	printf("enter total credits\n");
	scanf_s("%f",& d);
	printf("enter credits limit\n");
	scanf_s("%f", &e);

	f = b + c - d;
	if (f >b)
	{
		printf(" account: %d\n",a);
		printf(" credits limit:%f\n",e);
		printf(" balance: %f \n",f);
		printf("credits limit exceeded");
	}
	system("pause");
    return 0;
}